#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

static int gvar;

sem_t mutex;

void *fun(void *arg)
{
	char *var = (char *)arg;
	// wait
	sem_wait(&mutex);
	printf("\nEntered..\n");

	// critical section
	printf("Critical Section in Progress>> \n");
	printf("arg is: %s\n", var);
	gvar++;
	sleep(4);

	// signal
	printf("\nJust Exiting...\n");
	sem_post(&mutex);
	return (void **)&gvar;
}

int main()
{
	sem_init(&mutex, 0, 1);
	int *retval;
	pthread_t t1, t2;

	pthread_create(&t1, NULL, fun, "Madhav");

	sleep(2);

	pthread_create(&t2, NULL, fun, "Mohan");

	pthread_join(t1, (void **)&retval);

	pthread_join(t2, (void **)&retval);
	printf("Gvar value after exe of t2: %d\n", *retval);

	sem_destroy(&mutex);
	return 0;
}
