#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <fcntl.h>
#include <unistd.h>


sem_t *mutex;

static int gvar;

void *fun(void *arg)
{
    char *var = (char *)arg;
    // wait
    sem_wait(mutex);
    printf("\nEntered..\n");

    // critical section
    printf("Critical Section in Progress>> \n");
    printf("arg is: %s\n", var);
    gvar++;
    sleep(4);

    // signal
    printf("\nJust Exiting...\n");
    sem_post(mutex);
    return (void **)&gvar;
}

int main()
{
    int sval, *retval;
    pthread_t t1, t2;

    mutex = sem_open("/semph", O_RDWR | O_CREAT, 0664, 1); 

    if (mutex == SEM_FAILED)
    {
        perror("Error In Open");
        return -1;
    }

    pthread_create(&t1, NULL, fun, "Madhav");

    sleep(2);

    pthread_create(&t2, NULL, fun, "Mohan");

    pthread_join(t1, (void **)&retval);

    pthread_join(t2, (void **)&retval);
    printf("\nGvar value after exe of t2: %d\n", *retval);

    sem_getvalue(mutex, &sval);
    printf("sem_val after post():%d\n", sval);

    sem_close(mutex);
    sem_unlink("/semph");  // destroy the "/semph"

    return 0;
}
