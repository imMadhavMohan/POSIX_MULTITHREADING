#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

static void *fun(void *arg)
{
    char *str = (char *)arg;  
    printf("thread is exe\n"); 
    sleep(4);
    printf("Exiting the thread\n");
    return(0);
}

int main()
{     	
    pthread_t t;
    int s;
    s = pthread_create(&t, NULL, fun, "thread_creation!"); 

    if (s != 0)
        printf("Error in creation\n");    

    sleep(2);

    printf("\nmain thread: exit() now\n");
    exit(0); // terminate all the sub threads & exit
}
