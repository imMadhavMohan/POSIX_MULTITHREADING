#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

pthread_mutex_t mtx;

static int glob = 0;

static void *threadFunc1(void *arg)
{
    int loc;
    int loop = 10000;
    //pthread_mutex_lock(&mtx);
    for (int i = 0; i < loop; i++) {
        loc = glob;
        loc++;
        glob = loc;        
        }
    //pthread_mutex_unlock(&mtx);
    return NULL;
}

static void *threadFunc2(void *arg)
{
    int loc;
    int loop = 10000;
    //pthread_mutex_lock(&mtx);
    for (int i = 0; i < loop; i++) {
        loc = glob;
        loc++;
        glob = loc;        
        }
   //pthread_mutex_unlock(&mtx);
    return NULL;
}


int main(int argc, char *argv[])
{
    pthread_t t1, t2;
    int s;
    s = pthread_create(&t1, NULL, threadFunc1, NULL);
    if (s != 0)
        perror("pthread_create");

    s = pthread_create(&t2, NULL, threadFunc2, NULL);
    if (s != 0)
        perror("pthread_create");

    s = pthread_join(t1, NULL);    
    if (s != 0)
        perror("pthread_join");

    s = pthread_join(t2, NULL);
    if (s != 0)
        perror("pthread_join");
        
    printf("glob = %d\n", glob);
    exit(0);
}
