#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

void *fun(void *arg)
{
    char *str = (char *)arg;      
    
    int i=0;
    for(i=0;i<100;i++); 
      sleep(10);
    
    printf("The arg recv is: %s\n", str);  
    printf("Thread fun exiting now\n");

    if(i<100)
        return (void*) "i<100"; // void fun as return type
    else 
        return (void*) "i>100"; 
}

int main()
{
    pthread_t t;
    int s;      
    void *ret;
    
    s = pthread_create(&t, NULL, fun, "Linux! user"); 
    if (s != 0)
        printf("Error in execution\n");

    s = pthread_join(t, &ret);
    
    if(s!=0)
       perror("Pthread_join error\n");
    else 
       printf("in main thread: thread returns: %s",(char*)ret);   

    printf("\nmain thread: exit() now\n");
    pthread_exit(NULL); 
}




