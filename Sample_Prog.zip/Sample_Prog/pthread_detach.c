#include <stdio.h>
#include <pthread.h>
#include<string.h>
#include <stdlib.h>
#include <unistd.h>

void *fun(void *arg){
    char *str = (char*)arg;
    printf("thread: arg is- %s\n",str);
    sleep(2);
    printf("calling thread exits\n"); // no need to wait for join by main thread,                               	      
}

int main(){
    pthread_t t;
    int s;
    s = pthread_create(&t,NULL,fun,"Pthread_Detach\n");
    
    if(s!=0)
        perror("Fail thread creation\n");

    s = pthread_detach(t);   // detach from main thread
    
    if(s!=0)
        perror("Thread_Detach Failure \n");
        	    
    printf("Main thread exits\n");

    pthread_exit(0); 
    return 0;
}

// To allow other threads to continue execution, the main thread should terminate by calling pthread_exit() rather than exit(1).
