#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h> 

void *fun(void *arg)
{
    char *str = (char *)malloc(30*sizeof(char));
    strcpy(str, "Hi!, ");
    strcat(str, (char*)arg);
    sleep(4);
    printf("Exiting the calling thread\n");
    pthread_exit(str);
}

int main()
{
    pthread_t t;
    int s;
    void *ret;
    s = pthread_create(&t, NULL, fun, " Madhav Mohan"); // Null- no arg to be passed

    if (s != 0)
        printf("Error in creation\n");


    sleep(2);
	
    if (pthread_join(t, &ret) != 0) {
    	perror("pthread_join() error");
    	exit(-3);
    }
    printf("thread exited with '%s'\n", (char*)ret);	
    
    printf("\nmain thread: exit() now\n");
    return 0;
}


// To allow other threads to continue execution, the main thread should terminate by calling pthread_exit() rather than exit(1).

