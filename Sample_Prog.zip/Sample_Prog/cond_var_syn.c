#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;   // ~ default attr pthread_mutex_init(&mtx, NULL)
pthread_cond_t cond_var = PTHREAD_COND_INITIALIZER;

int meals = 0;
char buf[100];

/* Producer thread*/
void *threadA(void *p)
{
    printf("\nthreadA Scheduled\n");
    pthread_mutex_lock(&mtx);
    printf("\nthreadA: Enters into critical section\n");
    printf("\nthreadA: Critical section is processing>> \n");
    /*producer will produce data here*/
    
    for (int i = 0; i < 100; i++)
        meals++;
    printf("\nthreadA: meals after production>> %d\n", meals);
    sprintf(buf, "Pay 1500 Rs.");
    pthread_cond_signal(&cond_var); // send signal to thread-B
    printf("\nthreadA: signal sent & terminates>> \n");
    pthread_mutex_unlock(&mtx);
}

/*Consumer thread*/
void *threadB(void *p)
{
    printf("\nthreadB Scheduled\n");    
    pthread_mutex_lock(&mtx);
    printf("\nthreadB: Enters into critical section\n");
    if (!meals)                               // donemeals == 0
        pthread_cond_wait(&cond_var, &mtx);      // mtx is unlocked & mtx lock is acquired by threadA
                                                 // once signal received from producer lock again acquired
    printf("\nthreadB: signal received from threadA>> \n");
    printf("\nthreadB: the value of meals Before Conumption>> %d\n", meals);
    printf("\nthreadB: Critical section is progressing>> \n");
    /*consumer will consume data here*/
    for (int i = 0; meals > 0; i++)
        meals--;
    printf("\nthreadB: meals value after consumption>> %d\n", meals);
    printf("\nthreadB: the msg received from thread-A>> (%s)\n", buf);
    printf("\nthreadB: terminates>> \n");
    pthread_mutex_unlock(&mtx);
}

int main()
{
    pthread_t pthreadA;
    // pthread_create(&pthreadA, NULL, threadA, NULL);

    pthread_t pthreadB;
    pthread_create(&pthreadB, NULL, threadB, NULL);
    pthread_create(&pthreadA, NULL, threadA, NULL);

    pthread_join(pthreadA, NULL);
    pthread_join(pthreadB, NULL);
    printf("\nMain thread is exiting now\n");
    pthread_mutex_destroy(&mtx);
    return 0;
}
