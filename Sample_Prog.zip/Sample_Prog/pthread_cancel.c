#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

void* fun(void* arg){
    printf("thread_arg: %s",(char*)arg);
    int i=0;
    while(1){
        sleep(1);
        printf("\nthread: %d iteration \n",i++);
    }
    sleep(2); 
    printf("thread: fun exits\n");
    return NULL;	
}

int main(){
    pthread_t t;
    int s = pthread_create(&t,NULL,fun,"Pthread_Cancel\n");

    if(s!=0)
        perror("error in create\n");

    for(int i=0;i<5;i++)
    {
        sleep(1); 
        printf("\ncount is: %d\n",i); 
    }
    
    // pthread_join(t, NULL); else the thread won't terminate
    pthread_cancel(t);
    
    printf("Main thread exits\n");
}
